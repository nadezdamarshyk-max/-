BOT_TOKEN ='6331007270:AAEd4WRyZhXAqD5Jv79qTAX4vKM2cPJB1oo'
# test= -1001823619866
# orig= -1001823619866
chat_id = -1001912576518
owner_id = 6609249703
group_newbot = -1001912576518
Test_group = -946101717
offical_group = -1001912576518
log_group = -946101717
channel_offical = -1001824759405
report_group = -946101717
BOT_NICKNAME = '@end_soft'

# СЛИВЫ ТОЛЬКО ЗДЕСЬ https://end_soft.t.me
